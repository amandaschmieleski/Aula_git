from django.apps import AppConfig


class InternacionalConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'internacional' #
