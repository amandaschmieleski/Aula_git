document.addEventListener('DOMContentLoaded', function() {
    console.log('JavaScript do aplicativo Internacional carregado!');
});