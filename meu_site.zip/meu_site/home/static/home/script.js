document.addEventListener('DOMContentLoaded', function() {
    console.log('JavaScript do aplicativo Home carregado!');
});