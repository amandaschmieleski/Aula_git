document.addEventListener('DOMContentLoaded', function() {
    console.log('JavaScript do aplicativo Seguro de Carros carregado!');
});