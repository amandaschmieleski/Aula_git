from django.apps import AppConfig


class SeguroCarrosConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'seguro_carros'
